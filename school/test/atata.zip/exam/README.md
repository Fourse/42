# C Exam Alone In The Dark - Beginner

My initial solutions to 42's exam exercises
